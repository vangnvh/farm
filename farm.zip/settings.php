<?php

define( 'INC', 'includes' );

require( ABSPATH . INC . '/db.php' );

