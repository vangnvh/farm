<?php
define( 'ID', 'efarm');
define( 'META_TITLE', 'eFarm');
define( 'META_KEYWORD', 'eFarm');
define( 'META_DESCRIPTION', 'eFarm');
define( 'DB_HOST', '115.79.25.206' );
define( 'DB_PORT', '5432' );
define( 'DB_NAME', 'itada_db' );
define( 'DB_USER', 'postgres' );
define( 'DB_PASSWORD', 'itada@1234567!' );
define( 'LANGUAGE', 'vi' );
define( 'COMPANY_ID', 'ROOT' );
define( 'COMPANY_NAME', 'eFarm' );
define( 'COMPANY_LAT', '10.861177053727173' );
define( 'COMPANY_LNG', '106.74004260552694' );
define( 'URL', 'http://localhost:8082/farm/' );
define( 'DOC_PATH', 'http://localhost/document' );
define( 'CONTACT_EMAIL', 'info@vidu.vn');
define( 'CONTACT_TEL', '(+84) 382-253-3737');
define( 'CONTACT_FAX', '(+84) 382-253-3737');
define( 'CONTACT_ADDRESS', 'Tp. Hồ Chí Minh');
define( 'SERVER_URL', 'http://localhost/');
define( 'WS_HOST', '14.160.32.79');
define( 'WS_PORT', 8484);
define( 'ODD_COLOR', "#fffde7");
define( 'EVEN_COLOR', "#fff");
define( 'GOOGLE_API_KEY', 'AIzaSyA3mDc_R4Q5mX_AU9UMwsJbjljyTPvpqfM');
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

require_once( ABSPATH . 'settings.php' );
